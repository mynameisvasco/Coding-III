package aula13.countries;

public 	enum LocalityType
{
	CITY,
	VILLAGE,
	TOWN,
}